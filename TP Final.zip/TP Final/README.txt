# 15-112-TP
Kerry Dash. Term Project for 15-112 Spring 2022

Project Description
The name of my term project is Kerry Dash which is a game similar to the widely popular game Geometry Dash. In this game, the user can choose between the "Standard Mode" and the "Endless Mode" which will give the user finishable levels or unlimited obstacles to play on. When the player clicks on "Standard Mode", it will give the player two level options, and once the player clicks on a level, the game will start! The user must jump over obstacle (the spikes) or land onto obstacles (the steps and platform). If the user runs into a triangle or runs into the sides of a platform,
the level will be restarted. If the player is in "Standard Mode", once the player reaches the end, the main pop-up screen/menu will show up giving the user the option to choose another level or mode. In the "Endless Mode," the terrain will alternate between two mini levels, but the levels will get increasingly difficult based on where the user died the previous time they played on that particular terrain.

How To Run The Project
The game is all in a singular file, so by running the file TermProject.py, the game can be started.

Libraries
The libraries I am using is "cs112_s22_week6_linter" and "cmu_112_graphics."